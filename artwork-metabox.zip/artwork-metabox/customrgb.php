<?php
/**
  Plugin Name: Artwork Metabox
  Plugin URI: https://pagedesignlab.com
  Description: Manage Custom RGB Website Develop by Page Design Lab.
  Author: Arjun Sutradhar
  Version: 1.0.0
  Author URI: https://facebook.com/arjunsutradhar99
  License: GPLv2
**/


require('inc/singleproductpage_metabox.php');