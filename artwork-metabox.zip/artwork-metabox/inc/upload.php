<?php
	if (isset($_FILES['artwork_attach_file'])) {
		$file_tmp_name = $_FILES["artwork_attach_file"]["tmp_name"];
		$file_name = $_FILES["artwork_attach_file"]["name"];
		$rename_file_name = date('Y-m-d-H-i-s').'-artwork_'.$file_name;
		$atwork_upload_dir = '../../../uploads/artwork/';
		$upload_dir_file = $atwork_upload_dir.$rename_file_name;
		if (move_uploaded_file($file_tmp_name, $upload_dir_file)) {
		    echo 'success,'.$rename_file_name;
		}else{
		    echo "Sorry, there was an error uploading your file.";
		}
	}
?>